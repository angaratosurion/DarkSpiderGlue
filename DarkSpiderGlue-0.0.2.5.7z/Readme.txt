﻿1)To install just upload the files to the ftp server
2)Create an mysql database with the name darkspiderglue
3)Import The sql script to the database from the dbsql folder.
4)Configure the conenction string correctly.
Notes: default user is Administrator
default username:@dministrator
Also in asp_data fodleredit the spider_config.xml to whatever you want.